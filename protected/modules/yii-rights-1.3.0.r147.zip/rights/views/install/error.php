<div id="installer" class="error">

	<h2><?php echo Rights::t('install', 'Error'); ?></h2>

	<p class="red-text">
		<?php echo Rights::t('install', 'An error occurred while installing Rights.'); ?>
	</p>

    <p>
		<?php echo Rights::t('install', 'Please try again or consult the documentation.') ;?>
	</p>

</div>